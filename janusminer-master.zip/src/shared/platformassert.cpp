#include <climits>
#include <cstdint>
static_assert(CHAR_BIT == 8);
static_assert(sizeof(uint32_t) == 4);
