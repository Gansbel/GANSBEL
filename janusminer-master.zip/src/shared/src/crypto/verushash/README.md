This directory contains heaviliy modified code from the VerusCoin project.
